** *COMING UPDATES***
**TESTING UPDATING**
The new updates will include testing the frontend/interface of the web application utilizing Selenium.
*TOOLS & TECHNOLOGIES*
Technologies that will be implemented include but not limited to: Selenium framework, python. 
However, i may use JAVA/Javascript to conduct the testing.
Python have been used before to automate certain web tasks and activities, JAVA will be\
used as a last resort.
